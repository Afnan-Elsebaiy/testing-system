<?php

namespace App\Http\Livewire\LaravelExamples;

use Livewire\Component;

class UserManagement extends Component
{
    public function render()
    {
        return view('livewire.laravel-examples.user-management');
    }
}
